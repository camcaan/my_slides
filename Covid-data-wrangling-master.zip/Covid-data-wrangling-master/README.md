# Covid data wrangling
Graphs and Rmarkdown scripts for COVID-related data in Canada. 

* [Data visualization of Covid-19 in Canada](https://kt1720.github.io/Covid-data-wrangling/Canada.html)

